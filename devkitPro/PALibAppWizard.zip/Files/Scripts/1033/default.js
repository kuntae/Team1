/* 
   PALib AppWizard Project Creation Script  
   By Rodrigo Sieiro
   
   Based on OGRE AppWizards
*/

function OnFinish(selProj, selObj)
{
	try
	{
		var strProjectPath = wizard.FindSymbol("PROJECT_PATH");
		var strProjectName = wizard.FindSymbol("PROJECT_NAME");

		selProj = CreateProject(strProjectName, strProjectPath);

		AddCommonConfig(selProj, strProjectName);
		AddSpecificConfig(selProj, strProjectName, false);
		
        SetupFilters(selProj);

		var InfFile = CreateInfFile();
		AddFilesToProjectWithInfFile(selProj, strProjectName);
		SetCommonPchSettings(selProj);
		InfFile.Delete();
		var projName = strProjectPath + "\\" + strProjectName + ".vcproj";
		selProj.Object.Save();
	}
	catch(e)
	{
		if (e.description.length != 0)
			SetErrorInfo(e);
		return e.number
	}
}

function GetTargetName(strName, strProjectName, strResourcePath)
{
	var strTarget = strName;

		switch (strName)
		{
			case "docs/readme.txt":
				strTarget = "docs\\ReadMe.txt";
				break;
			case "data/logo.bmp":
				strTarget = "data\\logo.bmp";
				break;
			case "data/logo_wifi.bmp":
				strTarget = "data\\logo_wifi.bmp";
				break;
			case "source/main.cpp":
				strTarget = "source\\main.cpp";
				break;
			case "Makefile":
				strTarget = "Makefile";
				break;
			default:
				break;
		}
	return strTarget; 
}

function AddSpecificConfig(proj, strProjectName, bEmptyProject)
{
	
// RELEASE
// Set Configurations for Release|Win32

	debug = proj.Object.Configurations("Debug|Win32");
	proj.Object.RemoveConfiguration(debug);

	config = proj.Object.Configurations("Release|Win32");

	var outdir = config.OutputDirectory;
	var intdir = config.IntermediateDirectory;

	proj.Object.RootNamespace = CreateIdentifierSafeName(strProjectName);
	
	config.IntermediateDirectory = '$(ConfigurationName)';
	config.OutputDirectory = '$(ConfigurationName)';
	config.ConfigurationType = typeUnknown;

	var NMakeTool = config.Tools("VCNMakeTool");

	NMakeTool.BuildCommandLine = "make -r 2>&1 | sed -e \'s/\\(.[a-zA-Z]\\+\\):\\([0-9]\\+\\):/\\1(\\2):/\'";
	NMakeTool.Output = '$(ConfigurationName)\\$(ProjectName).nds';
	NMakeTool.CleanCommandLine = 'make clean';
	NMakeTool.ReBuildCommandLine = "make -r rebuild 2>&1 | sed -e \'s/\\(.[a-zA-Z]\\+\\):\\([0-9]\\+\\):/\\1(\\2):/\'";

	NMakeTool.PreprocessorDefinitions = 'WIN32;NDEBUG;VC7';
	NMakeTool.IncludeSearchPath = '\"$(DKP_HOME)\\PAlib\\include\\nds\";\"$(DKP_HOME)\\PAlib\\include\\nds\\arm7\";\"$(DKP_HOME)\\PAlib\\include\\nds\\arm9\";\"$(DKP_HOME)\\PAlib\\include\\nds\\netinet\";\"$(DKP_HOME)\\PAlib\\include\\nds\\sys\"';
	NMakeTool.ForcedIncludes = '';
	NMakeTool.AssemblySearchPath = '';
	NMakeTool.ForcedUsingAssemblies = '';

}

function SetFileProperties(projfile, strName)
{
	return false;
}

function DoOpenFile(strTarget)
{
	return false;
}
