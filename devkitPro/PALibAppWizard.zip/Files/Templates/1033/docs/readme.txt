================================================================================
About the "[!output PROJECT_NAME]" Project
================================================================================

The PALib Application Wizard has created this PALib project for you.  It  serves
as a starting point, whether you want to do some quick  PALib testing,  or  just
want to create a PALib project.

---

About the PALib Application Wizard

You can  customize and  tweak all the wizard  files to your liking.  Take a look
at the "Templates" directory where you placed the PALib AppWizard.

This  PALib  Application  Wizard  for  Visual Studio 2005 Express was created by
Rodrigo Sieiro based on OGRE AppWizards.

PALib:
http://www.palib.com

OGRE:
http://www.ogre3d.org/

---

Happy coding :)

Rodrigo Sieiro
cheapo --at-- thechip.net
