--------------------------------------------------------------------------------
PALib Application Wizard for Visual Studio 2005
By Rodrigo Sieiro (cheapo --at-- thechip.net)
Version 1.0 (2006-10-20)
Based on OGRE AppWizard
--------------------------------------------------------------------------------

--- History --------------------------------------------------------------------

Version 1.0 (2006-10-20)
	- First Release.

--- Quick Install --------------------------------------------------------------

1) Place the PALibAppWizard folder inside your DevKitPro folder.
   (i.e. c:\devKitPro\PALibAppWizard)

2) Run VC8_Express_Setup.js or VC8_Setup.js (depending on your version of VC) to
install this PALib Application Wizard! (Double-click on it)

3) Remember: DO NOT delete this folder - your PALib Wizard needs the files.  The
install script changes the  ABSOLUTE_PATH  in  PALibAppWizard.vsz  to  point  to
wherever you put the wizard files.

NOTE: This  Wizard  depends upon you having setup  Internet Explorer  to  accept 
cookies.

If you have problems with another program having registered with .js files, like
Dreamweaver, try running manually from the "Run" box (Start -> Run):

WScript.exe <location of setup js>

If you don't have JScript installed, get it from Microsoft - it's free.

--- More Info ------------------------------------------------------------------

Check out the  guide in  PALib Wiki  (http://www.palib.info/wiki/)  for detailed
information about this AppWizard.

--- By Rodrigo Sieiro ----------------------------------------------------------