// PALib Application Wizard
// By Rodrigo Sieiro
// Based on OGRE Application Wizard
//
// This file is a part of the PALib Application Wizard.
// The code and information is provided "as-is" without
// warranty of any kind, either expressed or implied.

main();

function main()
{
	var bDebug = false;
	var Args = WScript.Arguments;
	if(Args.length > 0 && Args(0) == "/debug")
		bDebug = true;

	// Create shell object
	var WSShell = WScript.CreateObject("WScript.Shell");

	// Create file system object
	var FileSys = WScript.CreateObject("Scripting.FileSystemObject");

	// Get Current Path
	var strValue = FileSys.GetAbsolutePathName(".");
	if(strValue == null || strValue == "")
		strValue = ".";

	// Get the Files Folder
	var strSourceFolder = strValue + "\\" + "Files";
	if(bDebug)
		WScript.Echo("Source: " + strSourceFolder);

	// Check if Files Folder exists
	if(!FileSys.FolderExists(strSourceFolder))
	{
		WScript.Echo("ERROR: Cannot find Wizard folder (should be: " + strSourceFolder + ")");
		return;
	}

	// Find Where Visual Studio is Installed
	var strVC8Key = "HKLM\\Software\\Microsoft\\VCExpress\\8.0\\Setup\\VC\\ProductDir"; 
	try 
	{ 
		strValue = WSShell.RegRead(strVC8Key); 
	} 
	catch(e) 
	{ 
		var strVC8Key = "HKLM\\SOFTWARE\\Wow6432Node\\Microsoft\\VCExpress\\8.0\\Setup\\VC\\ProductDir"; 
		try 
		{ 
			strValue = WSShell.RegRead(strVC8Key); 
		} 
		catch(e) 
		{ 
			WScript.Echo("ERROR: Cannot find where Visual Studio 8.0 is installed."); 
			return; 
		} 
	}
	
	// Check for VCProjects Folder
	var strDestFolder = strValue + "\Express\\VCProjects";
	if(bDebug)
		WScript.Echo("Destination: " + strDestFolder);
	if(!FileSys.FolderExists(strDestFolder))
	{
		WScript.Echo("ERROR: Cannot find destination folder (should be: " + strDestFolder + ")");
		return;
	}

	// Check for NintendoDS Folder
	var strDestFolderDS = strValue + "\Express\\VCProjects\\NintendoDS";
	if(bDebug)
		WScript.Echo("Destination: " + strDestFolderDS);
	if(!FileSys.FolderExists(strDestFolderDS))
	{
		FileSys.CreateFolder(strDestFolderDS);
	}

	var strDest = strDestFolder + "\\";
	var strDestDS = strDestFolderDS + "\\";
	var strSrc = "";

	// Copy files
	try
	{
		strSrc = strSourceFolder + "\\PALibAppWizard.ico";
		FileSys.CopyFile(strSrc, strDest);

		strSrc = strSourceFolder + "\\PALibAppWizard.vsdir";
		FileSys.CopyFile(strSrc, strDestDS);
	}
	catch(e)
	{
		var strError = "no info";
		if(e.description.length != 0)
			strError = e.description;
		WScript.Echo("ERROR: Cannot copy file (" + strError + ")");
		return;
	}

	// Read and write PALibAppWizard.vsz, replace path when found
	try
	{
		strSrc = strSourceFolder + "\\PALibAppWizard.vsz";
		strDest = strDestFolder + "\\PALibAppWizard.vsz";

		var ForReading = 1;
		var fileSrc = FileSys.OpenTextFile(strSrc, ForReading);
		if(fileSrc == null)
		{
			WScript.Echo("ERROR: Cannot open source file " + strSrc);
			return;
		}

		var ForWriting = 2;
		var fileDest = FileSys.OpenTextFile(strDest, ForWriting, true);
		if(fileDest == null)
		{
			WScript.Echo("ERROR: Cannot open destination file" + strDest);
			return;
		}

		while(!fileSrc.AtEndOfStream)
		{
			var strLine = fileSrc.ReadLine();
			if(strLine.indexOf("ABSOLUTE_PATH") != -1)
				strLine = "Param=\"ABSOLUTE_PATH = " + strSourceFolder + "\"";
			fileDest.WriteLine(strLine);
		}

		fileSrc.Close();
		fileDest.Close();
	}
	catch(e)
	{
		var strError = "no info";
		if(e.description.length != 0)
			strError = e.description;
		WScript.Echo("ERROR: Cannot read and write PALibAppWizard.vsz (" + strError + ")");
		return;
	}

	WScript.Echo("PALib Application Wizard successfully installed!");
}
